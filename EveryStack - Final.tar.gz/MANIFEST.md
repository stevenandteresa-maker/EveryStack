# docs/reference — Document Manifest

> **Last full reconciliation: 2026-02-28** — All 63 documents (59 main + 4 gap) audited against `GLOSSARY.md` (source of truth). Full architectural audit (Issues #1–16) resolved — hierarchy rewrite, permission model, schema fixes, terminology standardization, sidebar architecture, MVP scope corrections. Every doc has a reconciliation note. Added `platform-api.md` (1145 lines) and `vertical-architecture.md` (535 lines) — Platform API & Vertical Architecture section. Post-reconciliation fixes (2026-02-28): fixed 102 broken `docs/reference/` cross-reference prefixes across 21 files; updated audit-log.md to seven-source attribution model (added `api_key` actor_type + `actor_label` column); resolved `environment` semantic collision (introduced `publish_state` for draft/live authoring workflow across 7 files); added missing standard columns to `tables`, `portal_access`, `synced_field_mappings`, `base_connections`; defined `conflict_resolution` type on `base_connections`; clarified phase playbook file location.
>
> Status of all reference documents. These are Tier 3 — loaded on demand, never auto-loaded.
> Each doc is a deep-dive spec for a specific domain. Phase build docs reference these.

## How Claude Code Uses This Manifest

When working on a feature, load the relevant reference doc(s) from `docs/reference/` for architectural context. Reference docs tell you HOW each system works and define scope (MVP vs. Post-MVP). Phase build docs (created per sprint) tell you WHAT to build and in what order — they override any sequencing in reference docs. Tier 2 directory CLAUDE.md files tell you the RULES for code in that directory.

---

## Document Status

### Manifest Statistics

| Metric | Count |
|--------|-------|
| Total docs | 63 (59 main + 4 gap) |
| MVP-relevant | 25 |
| Post-MVP | 32 |
| Historical | 1 |
| Meta (Glossary + Manifest) | 1 (GLOSSARY.md — MANIFEST.md is this file) |
| Gap: Merged | 2 |
| Gap: Superseded | 1 |
| Gap: Active (standalone post-MVP) | 1 |

---

### 🏗️ Foundation & Infrastructure

These docs define the platform's technical backbone: data model, scaling, design system, security, testing, and operational concerns. Most are MVP-relevant.

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `data-model.md` | 595 | **MVP** | Core schema: tenants, users, tables, fields, records (canonical JSONB), views, record_view_configs, cross_links, portals, forms, document_templates, automations, base_connections, threads, AI usage. Split portals/forms/apps tables per glossary. | `sync-engine.md`, `cross-linking.md`, `permissions.md`, `automations.md`, `ai-metering.md`, `smart-docs.md` | 2026-02-27 |
| `database-scaling.md` | 495 | **MVP** (core), post-MVP (CockroachDB, multi-region) | PgBouncer, `getDbForTenant()` read/write routing, hash partitioning, RLS at scale, tsvector indexing (4-weight system, `extractSearchableText()`), JSONB expression indexes, scaling decision points. | `cockroachdb-readiness.md` | 2026-02-27 |
| `design-system.md` | 357 | **MVP** | Hybrid color model (always-dark sidebar, white content, admin-chosen accent header), 8 workspace accent colors, 13-color data palette, DM Sans / JetBrains Mono, spacing scale, shadcn components, Record View/Record Thread overlay + Quick Panels in application shell, tablet as small computer, ergonomic design constraints, 3 creation flow patterns. | `tables-and-views.md`, `communications.md`, `command-bar.md`, `mobile.md` | 2026-02-28 |
| `files.md` | 340 | **MVP** | Upload pipeline (presigned URLs → R2/S3), `StorageClient` abstraction, content-type security (MIME allowlist, magic byte verification, SVG sanitization), image processing (sharp thumbnails, blurhash, Gotenberg PDF preview), virus scanning (ClamAV), file size limits per plan, CDN serving strategy, orphan cleanup. | `data-model.md`, `smart-docs.md`, `email.md`, `communications.md` | 2026-02-27 |
| `observability.md` | 173 | **MVP** | Pino with PII redaction, AsyncLocalStorage traceId, log levels, Sentry config, OTel auto-instrumentation, AI telemetry, 5 monitoring dashboards, 8 alerting rules with thresholds. | `workspace-map.md` *(post-MVP)* | 2026-02-27 |
| `operations.md` | 472 | **MVP** | Backup strategy (daily + WAL), RTO/RPO targets, Redis failover, incident response runbook, monitoring dashboards, scaling triggers, data breach notification. | `cockroachdb-readiness.md` *(post-MVP)*, `compliance.md`, `observability.md` | 2026-02-27 |
| `realtime.md` | 220 | **MVP** | Socket.io transport, room model, connection lifecycle, auth & authorization for subscriptions, reconnection strategy (exponential backoff, catch-up queries, stale data indicator), Redis pub/sub event bus, horizontal scaling (Redis adapter, sticky sessions), presence (TTL heartbeat), chat delivery, Hocuspocus strategy, capacity planning. | `embeddable-extensions.md` *(post-MVP)*, `approval-workflows.md` *(post-MVP)*, `workspace-map.md` *(post-MVP)*, `bulk-operations.md` | 2026-03-01 |
| `compliance.md` | 432 | **MVP** | GDPR rights, CCPA/CPRA, PII registry, anonymization cascade, encryption at rest/in transit, security headers (platform + portal CSP), RLS policy specs, webhook signature verification, Gotenberg sandboxing, WAF, session management, SSO (SAML), SCIM, API key security, vulnerability management, data breach notification, SOC 2 timeline (Type I Post-MVP — Comms & Polish). | `data-model.md`, `operations.md`, `files.md`, `ai-architecture.md` | 2026-02-27 |
| `testing.md` | 1011 | **MVP** | Test priorities (3 tiers), Vitest + Playwright + axe-core, test file conventions, test utilities (`testTenantIsolation()`, data factories, MSW mocks), security tests, Vitest/Playwright configs, Docker Compose test services, accessibility testing (WCAG 2.1 AA), performance regression testing, CI pipeline (GitHub Actions YAML), 9 pre-merge gates, coverage targets, staging DB seeding. | `observability.md`, `ai-architecture.md`, `data-model.md` | 2026-02-27 |
| `settings.md` | 113 | **MVP** | Settings page layout (sidebar nav + 720px content area), 9 sections (General, Members & Roles, Billing & Plan, AI & Credits, Integrations, Branding, Notifications, Data & Privacy, Advanced), role gating per section, auto-save pattern, functional specification (API/persistence, validation constraints, concurrent edit handling, plan enforcement, audit logging), progressive disclosure, mobile push navigation. | `design-system.md`, `permissions.md`, `ai-metering.md`, `communications.md`, `booking-scheduling.md` *(post-MVP)*, `compliance.md`, `command-bar.md`, `my-office.md` | 2026-03-01 |
| `cockroachdb-readiness.md` | 355 | **MVP** (safeguards only), post-MVP (deployment) | 13 CockroachDB-ready patterns, 9 migration items, `getDbForTenant()` CockroachDB routing, enterprise deployment architecture, 5 development safeguards (active from MVP — Foundation), CI integration test recommendation, 10-step migration playbook. | `database-scaling.md`, `compliance.md`, `vector-embeddings.md`, `operations.md`, `data-model.md`, `inventory-capabilities.md` | 2026-02-27 |

---

### 🔄 Sync Engine

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `sync-engine.md` | 1079 | **MVP** | CTL, FieldTypeRegistry, adapters (Airtable, SmartSuite, Notion), sync setup wizard (4-step), sync filters (per-table inbound FilterRule[]), record quota enforcement, orphaned records UX, progressive sync, optimistic UI, smart polling, rate limit management, conflict resolution UX (detection, manual mode, diff view, grid-level rendering), sync error recovery UX (8 error categories, 5 recovery flows), sync settings dashboard, `sync_failures` / `sync_schema_changes` tables. | `data-model.md`, `accounting-integration.md`, `approval-workflows.md` *(post-MVP)*, `inventory-capabilities.md`, `workspace-map.md` *(post-MVP)*, `field-groups.md`, `bulk-operations.md` | 2026-02-27 |

---

### 🖥️ Core UX

These docs define the user-facing workspace experience: views, records, cross-linking, command bar, field management, bulk operations, and mobile.

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `tables-and-views.md` | 842 | **MVP** | Table types (table, projects, calendar, documents, wiki), View types (Grid + Card MVP; Kanban, List, Gantt, Calendar post-MVP), Record View overlay (configurable field canvas, columns, tabs), My Views + Shared Views, Table View as access boundary, CSV/data import (MVP — Core UX), Quick Entry *(post-MVP)*. | `data-model.md`, `cross-linking.md`, `permissions.md`, `mobile.md` | 2026-03-01 |
| `cross-linking.md` | 573 | **MVP** | Cross-platform record relationships, data model (`cross_links`, `link_scope_filter`), query-time resolution (Level 0–2), cycle detection, cross-link permission resolution, cascade engineering (single-hop rule, BullMQ dedup), link scope filters, scalability (tiered integrity sampling), impact analysis (3-tier consequence model), convert to native table. | `data-model.md`, `permissions.md`, `tables-and-views.md`, `sync-engine.md` | 2026-02-27 |
| `command-bar.md` | 163 | **MVP** | ⌘K / Ctrl+K universal search and command interface. Record search, table navigation, slash commands (~18 MVP commands), natural language AI search via SDS. | `data-model.md`, `communications.md`, `automations.md`, `schema-descriptor-service.md` | 2026-02-27 |
| `field-groups.md` | 569 | **MVP** (MVP — Core UX) | Named field groups with group coloring (3 modes), collapse behavior, per-field emphasis (bold header, accent color), conditional cell coloring cascade (4-level priority), enhanced hide/show panel, synced table tab badges, sidebar board collapse behavior. | `tables-and-views.md`, `data-model.md`, `design-system.md`, `sync-engine.md`, `permissions.md`, `mobile.md` | 2026-02-27 |
| `bulk-operations.md` | 571 | **MVP** (MVP — Core UX) | Multi-record selection model (checkbox column, 5K cap), bulk action toolbar (7 actions: delete/edit/duplicate/copy/assign/export/run automation), binary gating (no partial success), approval-gated field exclusion, batch server actions (`bulk.ts`), audit log condensation, real-time event batching, formula cascade throttling, undo mechanism (≤50 records). | `tables-and-views.md`, `permissions.md`, `approval-workflows.md` *(post-MVP)*, `audit-log.md`, `automations.md`, `realtime.md`, `formula-engine.md` *(post-MVP)*, `cross-linking.md`, `sync-engine.md`, `data-model.md`, `inventory-capabilities.md`, `record-templates.md` | 2026-02-27 |
| `record-templates.md` | 863 | **MVP** (MVP — Core UX + Post-MVP — Automations) | `record_templates` table, dynamic tokens ($me/$today/$context_record), `record_creation_source` enum, value resolution order, template picker UX (split button, dropdown, mobile bottom sheet), view-contextual overrides (Kanban column→status, Calendar slot→date), App scoping, portal form integration, Command Bar auto-registration, Quick Entry `template_id`, contextual creation (right-click, linked record "+"). | `data-model.md`, `tables-and-views.md`, `automations.md`, `app-designer.md`, `command-bar.md`, `permissions.md`, `cross-linking.md`, `inventory-capabilities.md`, `custom-apps.md` *(post-MVP)*, `design-system.md`, `mobile.md`, `bulk-operations.md` | 2026-02-27 |
| `my-office.md` | 360 | **MVP** | Personal home screen widget grid (Tasks, Calendar, Chat/DMs, Workspaces list), expandable sidebar architecture (48px collapsed / ~280px expanded), Quick Panel context-dependent behavior (My Office: 2/3 widget expansion; workspace: 25% side panel), desktop 3-column layout, mobile workspace tiles with bottom tab bar. | `data-model.md`, `communications.md`, `command-bar.md`, `mobile.md` | 2026-02-28 |
| `mobile.md` | 1232 | **MVP** | Device tier strategy (phone/tablet/desktop), primary mobile surfaces, mobile chat & messaging, mobile view types (card primary, kanban, calendar, form), portal mobile PWA, camera scanning & OCR, maps & geolocation, voice input, mobile input optimization, ergonomic design (thumb zone), offline architecture, notification routing, deep linking, performance budgets, Capacitor framework, testing matrix. | `inventory-capabilities.md`, `tables-and-views.md`, `data-model.md`, `custom-apps.md` *(post-MVP)*, `approval-workflows.md` *(post-MVP)*, `chart-blocks.md`, `booking-scheduling.md` *(post-MVP)*, `record-templates.md`, `workspace-map.md` *(post-MVP)*, `field-groups.md` | 2026-02-27 |
| `mobile-navigation-rewrite.md` | 550 | **MVP** (Draft) | Two-layer bottom bar navigation rewrite, renamed Interface → Table View throughout. | `mobile.md`, `tables-and-views.md`, `command-bar.md`, `design-system.md` | 2026-02-27 |

---

### 🌐 Portals & Forms

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `portals.md` | 531 | **MVP** (Quick Portals), post-MVP (App Portals via App Designer) | MVP (Part 1): `portals` table (with `record_view_config_id`, `auth_type`, `status`, `settings` JSONB), `portal_access` table (Quick Portal auth), `portal_sessions` (polymorphic — shared by Quick and App Portals), magic link / password auth, auth failure paths (password/magic link/session error handling, password reset), single-record scoping via `portal_access.record_id`, selectively editable fields, portal file uploads, three-tier caching, rate limiting, audit logging, GDPR endpoints, plan limits. Post-MVP (Part 2): summary referencing `app-designer.md` for App Portal spec — `apps`/`app_pages`/`app_blocks`/`portal_clients` tables, identity-based scoping, themes, multi-page, data binding, analytics, payments, PWA, custom domains. Both portal types coexist permanently. | `GLOSSARY.md`, `data-model.md`, `app-designer.md` *(post-MVP)*, `automations.md`, `compliance.md` | 2026-03-01 |
| `forms.md` | 182 | **MVP** (Quick Forms), post-MVP (App Forms via App Designer) | Quick Forms: `forms` table (with `record_view_config_id`, `slug`, `status`, `settings` JSONB), `form_submissions` table, Record View layout for record creation, Cloudflare Turnstile spam protection, submission flow (7-step), comprehensive error handling (validation, rate limiting, duplicate prevention, accessibility), notification emails, standalone URL + embed (script/iframe), required field overrides, mobile single-column rendering. App Forms (post-MVP): see `app-designer.md`. | `data-model.md`, `tables-and-views.md`, `portals.md`, `app-designer.md` *(post-MVP)*, `design-system.md` | 2026-03-01 |

---

### 📝 Documents

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `smart-docs.md` | 421 | **MVP** | TipTap editor architecture (2 environments: chat editor env 1, Smart Doc env 2), wiki mode + template mode, merge-tag document generation, PDF output via Gotenberg, AI draft option, Smart Doc field type, versioning, snapshot system. | `data-model.md`, `communications.md`, `automations.md`, `tables-and-views.md`, `email.md` | 2026-02-27 |

---

### ⚡ Automations

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `automations.md` | 527 | **MVP** (linear flows), post-MVP (visual canvas, branching, conditions) | MVP: 6 triggers, 7 actions, step-by-step list builder, no branching. Full 22-trigger/42-action spec preserved in session archives for post-MVP. Trigger detection, execution model, error handling. | `data-model.md`, `email.md`, `smart-docs.md`, `communications.md` | 2026-02-27 |

---

### 💬 Communications

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `communications.md` | 458 | **MVP** (Record Thread + DMs + group DMs), post-MVP (base/table threads, omnichannel) | Record Thread (contextual record-scoped comments, @mentions, activity), DMs (personal 1:1 messaging), group DMs (3–8 people), Chat Editor (TipTap env 1), notification system (data model, delivery pipeline, notification types, API, error handling), messaging error handling. | `data-model.md`, `tables-and-views.md`, `my-office.md`, `email.md` | 2026-03-01 |
| `email.md` | 300 | **MVP** (system emails), post-MVP (CRM Post-MVP — Documents, connected inbox Post-MVP — Comms & Polish) | Resend transactional email, email templates, email events tracking, notification delivery, automation Send Email action. | `data-model.md`, `communications.md`, `automations.md`, `smart-docs.md` | 2026-02-27 |

---

### 🤖 AI Layer

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `ai-architecture.md` | 376 | **MVP** | AIProviderAdapter interface, capability-based routing (fast/standard/advanced tiers), prompt registry with versioning, tool definitions, evaluation framework, MCP server/client, fallback chains, cost normalization, structured output (Zod → aiToCanonical), agent integration hooks, self-hosted LLM architecture. | `agent-architecture.md`, `ai-metering.md`, `ai-data-contract.md`, `ai-field-agents-ref.md`, `accounting-integration.md`, `gaps/knowledge-base-live-chat-ai.md` | 2026-02-27 |
| `ai-data-contract.md` | 220 | **MVP** | AI as formal data boundary: `canonicalToAIContext()` (read path) and `aiToCanonical()` (write path). Per-field-type mapping for all 40 field types. AI Feature Integration Matrix. DuckDB exemption. Validation pipeline. | `ai-architecture.md`, `data-model.md`, `sync-engine.md`, `ai-field-agents-ref.md` *(post-MVP)*, `duckdb-context-layer-ref.md` *(post-MVP)*, `inventory-capabilities.md` *(post-MVP)*, `document-intelligence.md` *(post-MVP)* | 2026-02-27 |
| `ai-metering.md` | 438 | **MVP** | AI credit system, rate card, model routing, credit budgets, metering flow, admin dashboard, user usage view, daily caps, alerts, reconciliation, data retention, pre-launch testing framework. Per-Feature Breakdown with credit costs. | `ai-architecture.md`, `data-model.md`, `command-bar.md`, `ai-field-agents-ref.md`, `chart-blocks.md`, `document-intelligence.md`, `gaps/knowledge-base-live-chat-ai.md` | 2026-02-27 |
| `schema-descriptor-service.md` | 539 | **MVP** (MVP — Core UX) | SDS: read-only module exposing workspace schema in LLM-optimized format. WorkspaceDescriptor JSON output. Permissions integration (per-user filtered). 3 API endpoints. 2-tier caching with schema_version_hash invalidation. Token budget estimator (3-level condensation). 8-prompt Claude Code roadmap. | `ai-architecture.md`, `data-model.md`, `permissions.md`, `cross-linking.md`, `vector-embeddings.md` *(post-MVP)*, `ai-data-contract.md`, `agent-architecture.md` *(post-MVP)*, `command-bar.md`, `duckdb-context-layer-ref.md` *(post-MVP)*, `workspace-map.md` *(post-MVP)* | 2026-02-27 |

---

### 🔒 Permissions & Audit

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `permissions.md` | 452 | **MVP** | 5 workspace roles (Owner/Admin/Manager/Team Member/Viewer), Table View as access boundary (fully reconciled — all "interface" terminology replaced), field-level permissions (3 states: read-write/read-only/hidden), two-layer restriction model (role-level + individual overrides), permission storage on `views` table JSONB, runtime resolution algorithm, permission denial behavior (error shape, UI patterns, audit logging), tenant isolation cross-reference, caching (session + Redis), portal client permissions (MVP: field selection on `portals` table; post-MVP: App Designer `app_blocks` data_binding). | `data-model.md`, `cross-linking.md`, `tables-and-views.md`, `portals.md` | 2026-03-01 |
| `audit-log.md` | 351 | **MVP** | Seven-source attribution (user/sync/automation/portal_client/agent/system/api_key), `audit_log` schema, `actor_label` display column, retention (90 days active + archive), Record Activity tab, workspace audit log, Custom Apps audit events (post-MVP), bulk audit condensation. | `approval-workflows.md` *(post-MVP)*, `custom-apps.md` *(post-MVP)*, `agent-architecture.md` *(post-MVP)*, `bulk-operations.md`, `platform-api.md` | 2026-02-27 |

---

### 🔌 Platform API & Vertical Architecture

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `platform-api.md` | 1170 | **MVP** (phased: foundation MVP — Foundation, Data API MVP — Core UX, Provisioning Post-MVP — Portals & Apps, full surface Post-MVP — Automations) | External REST API: auth (service-level API keys with scoping — `api_keys` table, SHA-256 hashed, `esk_live_`/`esk_test_`/`esk_platform_` prefixes), Data API (Record CRUD, Table queries, filter syntax, batch create, cursor pagination), Schema API (Workspace/Table/Field/Cross-Link structure, SDS endpoint), Provisioning API (create Workspaces, Tables, Fields, Cross-Links, Automations, Quick Portals, Quick Forms, Record View Configs, Document Templates, Portal Access, document generation), AI API (AIService consumption via capability tiers, prompt template registration), Automation API (trigger via webhook and API key, run status), Webhook Management API (endpoint registration, delivery log), File Upload API (presigned URLs), Tenant Management API (Tenant creation with platform-level keys). Rate limiting (4 tiers, Redis token bucket), versioning (URL-based `/api/v1/`), error format (structured JSON with codes), audit integration (`actor_type: 'api_key'`), `api_request_log` table (monthly partitioned, 30-day retention). | `vertical-architecture.md`, `GLOSSARY.md`, `data-model.md`, `automations.md`, `ai-architecture.md`, `ai-metering.md`, `compliance.md`, `audit-log.md`, `permissions.md`, `sync-engine.md`, `schema-descriptor-service.md`, `cross-linking.md`, `portals.md`, `forms.md`, `smart-docs.md`, `realtime.md`, `settings.md`, `files.md` | 2026-02-28 |
| `vertical-architecture.md` | 556 | **MVP** (strategy — informs Platform API design and phasing) | Architecture guide for branded vertical products on EveryStack engine. Product family model (horizontal platform + B2B branded verticals + B2C direct products), three-layer architecture (Vertical Application → Domain Data → EveryStack Engine), B2B patterns (auth via service API keys, provisioning flow, industry templates), B2C patterns (single-Tenant model, heavy domain services), three separation boundaries (code, data, integration), platform reuse matrix (capability → reference doc mapping with MVP status), what verticals must build, data flow patterns (3 patterns: vertical creates Record, EveryStack notifies vertical, B2B provisioning), vertical evaluation criteria (leverage scoring, checklist, ranked candidates by tier), build sequence (4 phases), architectural decisions record. | `platform-api.md`, `GLOSSARY.md`, `data-model.md`, `portals.md`, `automations.md`, `ai-architecture.md`, `ai-metering.md`, `cross-linking.md`, `smart-docs.md`, `email.md`, `permissions.md`, `audit-log.md`, `realtime.md`, `compliance.md`, `settings.md`, `forms.md`, `sync-engine.md`, `schema-descriptor-service.md`, `booking-scheduling.md` *(post-MVP)*, `app-designer.md` *(post-MVP)*, `agency-features.md`, `files.md` | 2026-02-28 |

---

### 📐 Post-MVP — App Designer & Custom Apps

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `app-designer.md` | 1061 | **Post-MVP** | Visual page builder for all app types. 12-column grid canvas, recursive block tree, drag-and-drop, data binding, themes, preview/publish. 7 app types: Portal, Form, Website, Internal App, Widget, App Form, Document. Block library, property panel, responsive rendering. **Renamed from `interface-designer.md` on 2026-02-27.** | `data-model.md`, `smart-docs.md`, `document-designer.md`, `automations.md`, `agency-features.md`, `compliance.md`, `accounting-integration.md`, `inventory-capabilities.md`, `chart-blocks.md`, `custom-apps.md`, `embeddable-extensions.md`, `approval-workflows.md`, `booking-scheduling.md`, `my-office.md`, `record-templates.md`, `workspace-map.md`, `field-groups.md` | 2026-02-27 |
| `custom-apps.md` | 821 | **Post-MVP** (Post-MVP — Custom Apps) | Internal apps built on App Designer engine. POS as hero use case. Cart/Transaction block (session-scoped Zustand state, 9-step atomic completion flow), Stripe Terminal integration (3 paths: external reader, Tap to Pay, Smart Reader), kiosk mode, app creation wizard, starter templates (POS Terminal, Front Desk Kiosk, Warehouse Station). | `app-designer.md`, `tables-and-views.md`, `inventory-capabilities.md`, `mobile.md`, `automations.md`, `accounting-integration.md`, `permissions.md`, `data-model.md`, `cross-linking.md`, `chart-blocks.md`, `smart-docs.md`, `design-system.md`, `compliance.md`, `agency-features.md`, `record-templates.md`, `workspace-map.md` | 2026-02-27 |
| `document-designer.md` | 629 | **Post-MVP** | Document app type in App Designer. Fixed-size canvas (A4/Letter/Legal), PDF/DOCX output, merge tags, header/footer zones, template gallery, homegrown DOCX engine (no Docxtemplater dependency). | `app-designer.md`, `smart-docs.md`, `automations.md`, `data-model.md`, `compliance.md`, `chart-blocks.md`, `custom-apps.md` | 2026-02-27 |
| `embeddable-extensions.md` | 882 | **Post-MVP** | Three portal-adjacent extension products: Website Mode (App Designer as website builder, 6 new block types, AI-generated websites), Live Chat Widget (embeddable JS widget, shadow DOM, WebSocket transport, pre-chat form, CRM auto-linking), Commerce Embed (3 modes: single product/catalog/custom amount, Stripe Elements, line items). | `app-designer.md`, `communications.md`, `automations.md`, `design-system.md`, `data-model.md`, `compliance.md`, `realtime.md`, `email.md`, `booking-scheduling.md`, `gaps/knowledge-base-live-chat-ai.md`, `workspace-map.md` | 2026-02-27 |

---

### 📊 Post-MVP — Advanced Views & Workflows

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `approval-workflows.md` | 706 | **Post-MVP** (Mode 1+2 MVP — Core UX, Mode 3 Post-MVP — Automations) | Status field transition enforcement. 3 operating modes (simple select → gated transitions → approval chains). TransitionPrecondition (5 types), auto-advance, approval rules (3 approver types), approval requests runtime, enforcement layer (<50ms), 7 UI surfaces, override policy. | `data-model.md`, `automations.md`, `permissions.md`, `app-designer.md`, `audit-log.md`, `tables-and-views.md`, `design-system.md`, `mobile.md`, `my-office.md`, `communications.md`, `agency-features.md`, `inventory-capabilities.md`, `workspace-map.md`, `bulk-operations.md` | 2026-02-27 |
| `formula-engine.md` | 382 | **Post-MVP** | PEG parser + AST (peggy grammar), tree-walking evaluator with sandbox (100ms timeout, 50-node depth, 10K ROLLUP cap), dependency graph, circular reference detection, formula result caching in canonical_data, bulk recalculation, approval transition precondition consumer. | `inventory-capabilities.md`, `chart-blocks.md`, `approval-workflows.md`, `workspace-map.md`, `bulk-operations.md` | 2026-02-27 |
| `chart-blocks.md` | 1446 | **Post-MVP** (ProgressChart MVP — Core UX) | 8 chart types, 3 data binding modes (Table Aggregate/DuckDB Analytical/Metric Snapshots), `summary` view type, App chart rendering, Smart Doc chart embeds, Recharts component library, data palette colors, aggregate query engine, Redis chart cache, Kanban pipeline rollups. 10-prompt Claude Code roadmap. | `tables-and-views.md`, `app-designer.md`, `smart-docs.md`, `duckdb-context-layer-ref.md`, `schema-descriptor-service.md`, `data-model.md`, `design-system.md`, `agency-features.md`, `accounting-integration.md`, `project-management.md`, `formula-engine.md`, `ai-metering.md`, `mobile.md`, `custom-apps.md`, `booking-scheduling.md`, `workspace-map.md` | 2026-02-27 |
| `booking-scheduling.md` | 1156 | **Post-MVP** (Post-MVP — Portals & Apps (Fast-Follow)) | Calendar View architecture (day/week/month), bookable tables (4 types), computed availability engine, Scheduler block + public booking pages, booking lifecycle (8-step), routing forms, video conferencing (Zoom Post-MVP — Portals & Apps (Fast-Follow)), meeting polls, Quick Setup Wizard. 6 triggers, 3 actions, 5 recipes. 10-prompt roadmap. | `my-office.md`, `data-model.md`, `tables-and-views.md`, `app-designer.md`, `automations.md`, `communications.md`, `embeddable-extensions.md`, `project-management.md`, `design-system.md`, `mobile.md`, `permissions.md`, `chart-blocks.md`, `email.md`, `workspace-map.md` | 2026-02-28 |
| `meetings.md` | 641 | **Post-MVP** | Meeting `table_type` config overlay (`meeting_table_config`), agenda/action items/decision log patterns, pre-meeting prep, post-meeting AI summary, recurring meetings, dependencies on booking-scheduling, meeting type templates. | `tables-and-views.md`, `data-model.md`, `smart-docs.md`, `cross-linking.md`, `project-management.md`, `booking-scheduling.md`, `communications.md`, `mobile.md`, `record-templates.md`, `approval-workflows.md`, `mobile-navigation-rewrite.md` | 2026-02-27 |
| `project-management.md` | 144 | **Post-MVP** (mostly; some PM patterns MVP — Core UX) | `pm_table_config` overlay, dependencies (`record_dependencies`), resource profiles, Kanban/Gantt/Timeline views (all post-MVP per glossary), PM dashboard tabs (burndown, utilization, budget). | `data-model.md`, `tables-and-views.md`, `inventory-capabilities.md`, `chart-blocks.md`, `booking-scheduling.md` | 2026-02-27 |
| `inventory-capabilities.md` | 464 | **Post-MVP** (Primitives 1+3 MVP-adjacent) | 6 platform primitives: Atomic Quantity Operations (`adjustFieldValue()`), Barcode/QR Code field type (#41), Adjust Number Field action (#38), Quick Entry app mode, Snapshot/Freeze action (#39), Threshold-Based Triggers (#16). Stocktake workflow. 6-prompt roadmap. | `data-model.md`, `automations.md`, `tables-and-views.md`, `ai-data-contract.md`, `mobile.md`, `formula-engine.md`, `app-designer.md`, `sync-engine.md`, `cross-linking.md`, `project-management.md`, `accounting-integration.md`, `agency-features.md`, `custom-apps.md`, `approval-workflows.md`, `record-templates.md`, `bulk-operations.md` | 2026-02-27 |
| `workspace-map.md` | 1628 | **Post-MVP** (Post-MVP — Verticals & Advanced) | Full-screen interactive topology visualization. 14 node types, 28 edge types, cluster model (5 types), layered force-directed layout (Dagre + d3-force), 3 semantic zoom levels, impact analysis overlay (BFS traversal, 3-tier severity), React Flow @xyflow/react v12, 500-node soft cap, minimap, Command Bar integration, phone list view fallback. 10-prompt roadmap. | `schema-descriptor-service.md`, `cross-linking.md`, `automations.md`, `portals.md`, `custom-apps.md`, `smart-docs.md`, `sync-engine.md`, `ai-field-agents-ref.md`, `approval-workflows.md`, `formula-engine.md`, `chart-blocks.md`, `embeddable-extensions.md`, `booking-scheduling.md`, `communications.md`, `tables-and-views.md`, `data-model.md`, `permissions.md`, `design-system.md`, `mobile.md`, `observability.md`, `realtime.md`, `command-bar.md` | 2026-02-27 |

---

### 🧠 Post-MVP — AI & Intelligence

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `agent-architecture.md` | 636 | **Post-MVP** | AI agent identity & delegation (AgentSession, AgentScope), execution runtime (plan/act/observe loop on BullMQ), 3-layer memory system (working/episodic/shared), 5-tier approval model (distinct from record approval workflows), agent-specific tools, observability & debugging, safety framework (5 layers), 8 specialized agent types. | `ai-architecture.md`, `ai-metering.md`, `self-hosted-ai.md`, `automations.md`, `permissions.md`, `vector-embeddings.md`, `schema-descriptor-service.md`, `duckdb-context-layer-ref.md`, `ai-field-agents-ref.md`, `accounting-integration.md`, `approval-workflows.md`, `gaps/knowledge-base-live-chat-ai.md` | 2026-02-27 |
| `ai-field-agents-ref.md` | 1523 | **Post-MVP** | LLM-powered computed fields (cross-base awareness, aggregate context, multi-hop traversal). Agent configuration model, 10 output types, 3 field reference source types, aggregate context via DuckDB, 7-step prompt assembly pipeline, LLM router, output validation via aiToCanonical, execution engine with caching, 4 trigger modes, cost management, security (prompt injection mitigations). 8-prompt roadmap. | `schema-descriptor-service.md`, `duckdb-context-layer-ref.md`, `ai-data-contract.md`, `data-model.md`, `ai-architecture.md`, `ai-metering.md`, `permissions.md`, `cross-linking.md`, `agent-architecture.md`, `automations.md`, `workspace-map.md` | 2026-02-27 |
| `self-hosted-ai.md` | 277 | **Post-MVP** (Post-MVP — Self-Hosted AI) | Enterprise air-gapped AI. Qwen3 model family, vLLM/SGLang inference stack, hybrid routing (60% self-hosted / 35% API / 5% advanced), quality gap assessment, cost breakeven at ~75 Enterprise workspaces, 3 deployment modes (EveryStack-managed/BYOM/hybrid), security model, prompt template compilation. | `ai-architecture.md`, `ai-metering.md`, `compliance.md`, `agent-architecture.md` | 2026-02-27 |
| `duckdb-context-layer-ref.md` | 935 | **Post-MVP** | Read-only, ephemeral, in-process analytical query engine. QueryPlan → fetch from Postgres → load into DuckDB → execute analytical SQL → ContextResult. JSONB to DuckDB type coercion, cross-base JOINs (ANY/UNNEST patterns), SQL safety scanner, DuckDBPoolConfig (8 concurrent, 2GB total), performance targets (<2s full pipeline). 8-prompt roadmap. | `schema-descriptor-service.md`, `ai-data-contract.md`, `data-model.md`, `permissions.md`, `cross-linking.md`, `agent-architecture.md`, `compliance.md`, `chart-blocks.md` | 2026-02-27 |
| `vector-embeddings.md` | 238 | **Post-MVP** | pgvector, 6 entity types embedded (table schema, field definitions, record summaries, Smart Doc content, file content, KB articles), partitioned schema, content hash dedup, EmbeddingProvider interface, Command Bar Search Pipeline (4 parallel channels, RRF merging), embedding cost model. | `cockroachdb-readiness.md`, `gaps/knowledge-base-live-chat-ai.md`, `personal-notes-capture.md` | 2026-02-27 |
| `document-intelligence.md` | 727 | **Post-MVP** | File metadata extraction (EXIF), file content extraction (PDF/DOCX/XLSX + OCR), vision analysis & labeling, document-to-record extraction pipeline, asset version comparison (4 modes), content search integration (extends Command Bar), extraction templates, `file_embeddings` table. 12-prompt roadmap. | `files.md`, `vector-embeddings.md`, `ai-architecture.md`, `ai-data-contract.md`, `ai-field-agents-ref.md`, `agency-features.md`, `mobile.md`, `ai-metering.md`, `command-bar.md`, `data-model.md`, `gaps/knowledge-base-live-chat-ai.md`, `personal-notes-capture.md` | 2026-02-27 |
| `personal-notes-capture.md` | 875 | **Post-MVP** | Evernote competitor. TipTap-based notes, file-first capture, voice-to-text, 3 note types (text/file/voice), workspace-scoped personal tables, personal tasks/events integration, offline architecture, search via embeddings. | `smart-docs.md`, `my-office.md`, `command-bar.md`, `tables-and-views.md`, `mobile.md`, `document-intelligence.md`, `vector-embeddings.md`, `gaps/knowledge-base-live-chat-ai.md`, `permissions.md`, `files.md`, `data-model.md`, `app-designer.md` | 2026-02-27 |

---

### 🏢 Post-MVP — Business Features

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `accounting-integration.md` | 838 | **Post-MVP** (Post-MVP — Accounting Integration) | Unified accounting API (Apideck/Merge — QuickBooks, Xero, 1C). `invoice_table_config` + `expense_table_config` overlays. Financial snapshots, 7 automation actions (#31–37), invoice lifecycle, expense lifecycle with approval, Financial Command Center (4-tab App), AI financial intelligence, retainer management, multi-currency. | `data-model.md`, `automations.md`, `sync-engine.md`, `agency-features.md`, `app-designer.md`, `ai-architecture.md`, `agent-architecture.md`, `tables-and-views.md`, `compliance.md`, `inventory-capabilities.md`, `custom-apps.md`, `approval-workflows.md` | 2026-02-27 |
| `agency-features.md` | 328 | **Post-MVP** | Time tracking, asset library, ad platform integrations. Timer widget, billing rates, asset_versions, metric_snapshots. All clarified as post-MVP App portal features per glossary. | `data-model.md`, `automations.md`, `accounting-integration.md`, `inventory-capabilities.md`, `custom-apps.md`, `approval-workflows.md` | 2026-02-27 |

---

### 📜 Historical Reference

| Document | Lines | Scope | Key Content | Cross-References | Reconciled |
|----------|-------|-------|-------------|-----------------|------------|
| `session-log.md` | 736 | **Historical** | All 74 open questions resolved (Feb 7–10, 2026). 8 session notes with decision rationale. Pre-dates some current naming — terminology updated to glossary-current terms (2026-02-27) but original decision context preserved. Role names: "Builder" = Manager in current 5-role model. | Referenced by: phase playbooks for historical decision context | 2026-02-27 |

---

### 📋 Meta

| Document | Lines | Purpose | Reconciled |
|----------|-------|---------|------------|
| `GLOSSARY.md` | 876 | **Source of truth** for all naming, MVP scope, concept definitions, and DB entity mapping. If any doc contradicts this, the glossary wins. | 2026-02-28 |
| `MANIFEST.md` | — | This file. Index of all reference docs with status, scope, cross-references, and reading order. | 2026-02-28 |

**Note:** `claude.md` (referenced extensively in `session-log.md` and other docs) is the root CLAUDE.md config file at the repo root — not a reference doc. It lives at `CLAUDE.md` (repo root), not in `docs/reference/`.

---

## Gap Docs (`docs/reference/gaps/`)

| File | Lines | Status | Key Content |
|------|-------|--------|-------------|
| `gaps/portals-client-auth.md` | 16 | **MERGED** into `app-designer.md` (2026-02-12) | Portal auth model (password + magic link), identity-based record scoping, `portal_clients` table. Glossary reconciled 2026-02-27. |
| `gaps/automations-execution-triggers-webhooks.md` | 687 | **MERGED** into `automations.md` | Execution model (sequential pipeline), 30 action types, 5 condition types, template resolution engine, webhook architecture, builder interface. Full spec preserved for post-MVP. MVP automation list defined in GLOSSARY.md. Glossary reconciled 2026-02-27. |
| `gaps/tables-views-boundaries.md` | 536 | **SUPERSEDED** by `GLOSSARY.md` + `tables-and-views.md` (2026-02-13, updated 2026-02-28). Renamed from `gaps/tables-interface-boundaries.md` (2026-02-27). | Old 3-layer Interface architecture (Table View → Interface → My View) is no longer canonical. Glossary eliminates separate "Interface" entity — Table Views are the permission boundary with Shared Views and My Views. Do not use this doc's schemas for new work. |
| `gaps/knowledge-base-live-chat-ai.md` | 461 | **ACTIVE** (standalone post-MVP spec) | Resolves phantom "knowledge base" dependency across 5 docs. Design: one content source (wiki records), three surfaces (help center/internal reference/Live Chat AI). KB designation, Smart Doc content chunking + embedding, Live Chat AI retrieval pipeline (6-step), agent-assist mode. Cross-refs: `smart-docs.md`, `vector-embeddings.md`, `embeddable-extensions.md`, `document-intelligence.md`, `agent-architecture.md`, `communications.md`, `ai-architecture.md`, `ai-metering.md`. Glossary reconciled 2026-02-27. |

---

## Reference Doc Scope Map

When building a feature, load the reference docs that cover your target scope:

| Scope | Reference Docs |
|-------|---------------|
| **MVP — Foundation** | `data-model.md`, `database-scaling.md`, `design-system.md`, `observability.md`, `testing.md`, `ai-architecture.md`, `ai-data-contract.md`, `ai-metering.md`, `compliance.md` (security headers, encryption, RLS, webhook verification), `files.md`, `permissions.md` (workspace roles), `cockroachdb-readiness.md` (development safeguards), `platform-api.md` (api_keys, auth middleware, rate limiting, error format), `vertical-architecture.md` (strategy context) |
| **MVP — Sync** | `sync-engine.md`, `database-scaling.md` (tsvector), `field-groups.md` (synced table tab badges) |
| **MVP — Core UX** | `permissions.md`, `cross-linking.md`, `tables-and-views.md`, `data-model.md`, `mobile.md`, `mobile-navigation-rewrite.md`, `my-office.md`, `command-bar.md`, `communications.md`, `email.md`, `audit-log.md`, `settings.md`, `forms.md`, `schema-descriptor-service.md`, `ai-data-contract.md`, `field-groups.md`, `bulk-operations.md`, `record-templates.md`, `platform-api.md` (Data API, Schema API, File Upload API), `personal-notes-capture.md` |
| **MVP — AI** | `ai-architecture.md`, `ai-data-contract.md`, `ai-metering.md`, `schema-descriptor-service.md` |
| **MVP — API** | `platform-api.md`, `vertical-architecture.md` |
| **Post-MVP — Portals & Apps** | `portals.md`, `app-designer.md`, `chart-blocks.md`, `document-intelligence.md`, `embeddable-extensions.md` (Website Mode), `booking-scheduling.md`, `meetings.md`, `platform-api.md` (Provisioning API) |
| **Post-MVP — Documents** | `smart-docs.md`, `document-designer.md`, `gaps/knowledge-base-live-chat-ai.md` (wiki schema) |
| **Post-MVP — Automations** | `automations.md`, `gaps/automations-execution-triggers-webhooks.md`, `approval-workflows.md`, `inventory-capabilities.md` (automation actions), `record-templates.md` (automation integration), `bulk-operations.md` (run automation), `platform-api.md` (AI API, Automation API, Webhook API, Tenant API) |
| **Post-MVP — Comms & Polish** | `communications.md` (advanced), `realtime.md`, `email.md` (connected inbox), `mobile.md` (advanced), `operations.md`, `ai-metering.md` (admin dashboard), `compliance.md` (SOC 2, SSO), `document-intelligence.md` (vision analysis) |
| **Post-MVP — Verticals & Advanced** | `agency-features.md`, `accounting-integration.md`, `project-management.md`, `inventory-capabilities.md` (advanced), `chart-blocks.md` (DuckDB modes), `document-intelligence.md` (asset comparison), `embeddable-extensions.md` (Commerce Embed), `approval-workflows.md` (domain-specific migration), `workspace-map.md`, `formula-engine.md` |
| **Post-MVP — AI Agents** | `agent-architecture.md`, `ai-architecture.md`, `duckdb-context-layer-ref.md`, `ai-field-agents-ref.md`, `ai-data-contract.md`, `vector-embeddings.md` |
| **Post-MVP — Custom Apps** | `custom-apps.md`, `app-designer.md`, `mobile.md` (Capacitor), `embeddable-extensions.md` (Live Chat Widget), `communications.md` (omnichannel), `gaps/knowledge-base-live-chat-ai.md` (Live Chat AI) |
| **Post-MVP — Self-Hosted AI** | `self-hosted-ai.md`, `ai-architecture.md`, `ai-metering.md`, `compliance.md` |

---

## Cross-Reference Convention

- Reference docs reference each other: `See [doc-name.md] > Section Name`
- Phase build docs reference: `docs/reference/[doc-name.md]`
- Tier 2 CLAUDE.md files reference: `docs/reference/[doc-name.md]`
- Gap sections note their merge target at the top of each file
- Post-MVP cross-references are annotated with *(post-MVP)* to prevent premature loading

---

## Known Issues

| Issue | Affected Doc(s) | Details |
|-------|-----------------|---------|
| **~~Stale `interface-designer.md` filename in cross-references~~** | `data-model.md` | **RESOLVED 2026-02-28.** All references now point to `app-designer.md`. Legacy Tables section correctly references old `interface_definitions` entity name in removal context. |
| **~~`formula-engine.md` "Last updated" date inconsistency~~** | `formula-engine.md`, `ai-field-agents-ref.md` | **RESOLVED 2026-02-28.** Both trailing "Last updated" dates updated to 2026-02-27 (glossary reconciliation date). |
| **~~`bulk-operations.md` references `gaps/tables-interface-boundaries.md`~~** | `bulk-operations.md` (line 14) | **RESOLVED 2026-02-27.** Gap doc renamed to `gaps/tables-views-boundaries.md`. Cross-reference in `bulk-operations.md` updated. |
| **~~`design-system.md` references "board view"~~** | `design-system.md` | **RESOLVED 2026-02-28.** "board view" → "Kanban view" (post-MVP). Full reconciliation added: App Designer naming, post-MVP tags on Kanban/Calendar, application shell updated to Record View/Record Thread overlay + Quick Panels. |
| **~~`record-templates.md` still lists `interface-designer.md` in cross-refs~~** | `record-templates.md` | **RESOLVED 2026-02-27 (batch 2).** Cross-reference updated to `app-designer.md`. |
